package com.nau.main;

import com.nau.view.LoginView;

public class LoginApp {
	
	public static void main(String[] args) {
			
		new LoginView();

	}

}
