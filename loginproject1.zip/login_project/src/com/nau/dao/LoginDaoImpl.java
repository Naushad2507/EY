package com.nau.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.xdevapi.Result;
import com.nau.database.ConnectionFromPool;
import com.nau.model.Employee;
import com.nau.model.Login;

public class LoginDaoImpl extends LoginDaoAdaptor {

	@Override
	public Boolean udpatePassword(Integer userId, String newPassword) {

		String sql = "update login set password=? where userId=?";

		return false;
	}

//	private Connection connection;
//	{
//		try {
//			connection = ConnectionFromPool.getConnection();
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
//	}
	@Override
	public List<Login> getAllUsers() {
		String sql = "select * from login";
		List<Login> logins = new ArrayList<>();
		try (Connection connection = ConnectionFromPool.getConnection();
				PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_FORWARD_ONLY);) {
			ResultSet resultSet = statement.executeQuery();
			while (resultSet.next()) {
				Integer userId = resultSet.getInt(1);
				String password = resultSet.getString(2);
				String fname = resultSet.getString(3);
				String lname = resultSet.getString(4);
				logins.add(new Login(userId, password, lname, fname));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return logins;
	}

	public List<Login> getAllUsers1() {
		String sql = "select * from login";
		List<Login> logins = new ArrayList<>();
		try (Connection connection = ConnectionFromPool.getConnection();
				PreparedStatement statement = connection.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_UPDATABLE);) {
			ResultSet resultSet = statement.executeQuery();
			resultSet.next();
			while (resultSet.next()) {
				Integer userId = resultSet.getInt(1);
				String password = resultSet.getString(2);
				String fname = resultSet.getString(3);
				String lname = resultSet.getString(4);
				logins.add(new Login(userId, password, lname, fname));
				System.out.println(resultSet.isLast());
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return logins;
	}

	@Override
	public Login getUserById(Integer userId) {
		String sql = "select * from employee where userId = ?";
		Login login = null;
		try (Connection connection = ConnectionFromPool.getConnection();
				PreparedStatement statement = connection.prepareStatement(sql);) {
			statement.setInt(1, userId);
			ResultSet resultSet = statement.executeQuery();
			System.out.println("========== Table Info ===========");
			ResultSetMetaData rsmd = resultSet.getMetaData();
			int x = rsmd.getColumnCount();
			String c = rsmd.getColumnLabel(2);
			System.out.println(c);
			System.out.println(x);
			System.out.println("========== Table Info End ===========");
			if (resultSet.next()) {
				String password = resultSet.getString("password");
				String fname = resultSet.getString("fname");
				String lname = resultSet.getString("lname");
				login = new Login(userId, password, fname, lname);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return login;
	}

	@Override
	public Integer saveUser(List<Login> logins) {
		System.out.println("in dao");
//		try {
//			Statement statement = connection.createStatement();
//			for (Login login : logins) {
//				Integer userId = login.getUserId();
//				String password = login.getPassword();
//				String lname = login.getlName();
//				String fname = login.getFname();
//				String sql = "insert into login values(" + userId + ",'" + password + "','" + lname + "','" + fname
//						+ "')";
//				statement.addBatch(sql);
//			}
//			int count[] = statement.executeBatch();
//			return count.length;
//		} catch (SQLException e) {
//			e.printStackTrace();
//		}
		int count = 0;
		String sql = "insert into employee values(?,?,?,?)";
		Connection connection=null;;
		try {
			connection = ConnectionFromPool.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			connection.setAutoCommit(false);
			for (Login login : logins) {
				Integer userId = login.getUserId();
				String password = login.getPassword();
				String lname = login.getlName();
				String fname = login.getFname();
				statement.setInt(1, userId);
				statement.setString(2, password);
				statement.setString(3, fname);
				statement.setString(4, lname);
				statement.addBatch();
			}
			int counts[] = statement.executeBatch();
			count = counts.length;
			connection.commit();
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			System.out.println(e.getErrorCode());
			e.printStackTrace();
		}
		return count;
	}
}
