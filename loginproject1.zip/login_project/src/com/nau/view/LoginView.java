package com.nau.view;

import java.util.List;
import java.util.Scanner;

import com.nau.model.Login;
import com.nau.service.LoginService;
import com.nau.service.LoginServiceImpl;

public class LoginView {
	private Scanner input = new Scanner(System.in);
	LoginService loginService = new LoginServiceImpl();

	public LoginView() {
	//	newlogin();
	//	getUserById();
	//	getAllUsers();
		getAllUsers1();
	}
	private void getAllUsers1() { // Resultsets
		List<Login> logins = loginService.getAllUsers1();
		logins.forEach(l -> System.out.println(l));
	}
	private void getAllUsers() {
		List<Login> logins = loginService.getAllUsers();
		logins.forEach(l -> System.out.println(l));
	}

	private void getUserById() {
		System.out.println("Enter UserId : ");
		Integer userId = input.nextInt();
		Login login = loginService.getUserById(userId);
		if (login != null) {
			System.out.println("Welcome " + login.getFname() + " " + login.getlName());
		} else {
			System.out.println("Sorry , user id not available");
		}
	}

	private void newlogin() {
		System.out.println("=========  Login =========");
		System.out.println("Enter UserId: ");
		Integer userId = input.nextInt();
		System.out.println("Enter Password: ");
		String password = input.next();
		System.out.println(userId + " " + password); // logged
		Login login1 = new Login(userId, password, "RAkesh", "ROY");
		// Login login2 = new Login(121, password, "naushad", "akhtar");

		int count = loginService.addUser(login1);
		System.out.println("Total Saved " + count);
		;
	}
}
