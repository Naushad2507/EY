package com.nau.database;

class Hello {
	int x = 10;

	private static Hello hello;
	static {
		hello = new Hello();
	}

	private Hello() {
	}

	public static Hello getInstance() {
		return hello;
	}

	public void add(int i) {
		this.x = this.x + i;
	}

	public void print() {
		System.out.println(this.x);
	}
}

public class SingletonDemo {
	public static void main(String[] args) {
		Hello hello = Hello.getInstance();
		hello.add(10);
		hello.print();
		Hello hello1 = Hello.getInstance();
		hello1.print();
	}
}
